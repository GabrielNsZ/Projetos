import React from 'react';
import { TextInput, StyleSheet } from 'react-native';

export default function TaskInput({ value, onChangeText }) { [cite: 50, 51]
  return (
    <TextInput 
      placeholder="Adicionar nova tarefa..."
      value={value}
      onChangeText={onChangeText}
      style={styles.input}
    />
  );
}

const styles = StyleSheet.create({
  input: { borderBottomWidth: 1, marginBottom: 20, fontSize: 18, padding: 10 }
});