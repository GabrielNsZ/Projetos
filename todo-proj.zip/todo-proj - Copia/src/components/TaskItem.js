import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons'; [cite: 60, 61]

export default function TaskItem({ tarefa, onRemove, onToggle }) { [cite: 48, 49]
  return (
    <View style={styles.item}>
      <TouchableOpacity onPress={onToggle} style={styles.checkArea}>
        <Icon 
          name={tarefa.completed ? "check-circle" : "checkbox-blank-circle-outline"} 
          size={24} 
          [cite_start]color={tarefa.completed ? "green" : "gray"} [cite: 6, 61]
        />
        <Text style={[styles.text, tarefa.completed && styles.completedText]}>
          {tarefa.text}
        </Text>
      </TouchableOpacity>

      <TouchableOpacity onPress={onRemove}>
        <Icon name="trash-can-outline" size={24} color="red" /> [cite: 61]
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  item: { flexDirection: 'row', justifyContent: 'space-between', padding: 15, backgroundColor: '#fff', marginBottom: 10, borderRadius: 8, elevation: 2 },
  checkArea: { flexDirection: 'row', alignItems: 'center' },
  text: { fontSize: 16, marginLeft: 10 },
  completedText: { textDecorationLine: 'line-through', color: 'gray' } 
});