
  const removerTarefa = async (id) => {
    const novasTarefas = tarefas.filter(t => t.id !== id);
    setTarefas(novasTarefas);
    await AsyncStorage.setItem('@minhas_tarefas', JSON.stringify(novasTarefas));
  };

 
  const toggleTarefa = async (id) => {
    const novasTarefas = tarefas.map(t => 
      t.id === id ? { ...t, completed: !t.completed } : t
    );
    setTarefas(novasTarefas);
    await AsyncStorage.setItem('@minhas_tarefas', JSON.stringify(novasTarefas));
  };

  return (
    <View style={styles.container}>
      <FlatList 
        data={tarefas}
        keyExtractor={item => item.id.toString()}
        renderItem={({ item }) => (
          <TaskItem 
            tarefa={item} 
            onRemove={() => removerTarefa(item.id)} 
            onToggle={() => toggleTarefa(item.id)} 
          />
        )}
      />
      <Button 
        title="Adicionar Tarefa" 
        onPress={() => navigation.navigate('Adicionar')} 
      />
    </View>
  );
// ...