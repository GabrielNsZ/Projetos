import React, { useState } from 'react';
import { View, Button, StyleSheet } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import TaskInput from '../components/TaskInput'; 

export default function AddScreen({ navigation }) {
  const [texto, setTexto] = useState('');

  const salvarTarefa = async () => {
    if (!texto) return;
    try {
      const jsonValue = await AsyncStorage.getItem('@minhas_tarefas'); [cite: 106]
      const tarefasAtuais = jsonValue ? JSON.parse(jsonValue) : []; [cite: 108]
      
      const novaTarefa = { id: Date.now(), text: texto, completed: false };
      const listaAtualizada = [...tarefasAtuais, novaTarefa];

      await AsyncStorage.setItem('@minhas_tarefas', JSON.stringify(listaAtualizada)); [cite: 89]
      navigation.goBack(); [cite: 186, 193]
    } catch (e) { console.error(e); }
  };

  return (
    <View style={styles.container}>
      <TaskInput value={texto} onChangeText={setTexto} /> [cite: 190]
      <Button title="Salvar Tarefa" onPress={salvarTarefa} /> [cite: 176]
    </View>
  );
}

const styles = StyleSheet.create({ container: { flex: 1, padding: 20 } });